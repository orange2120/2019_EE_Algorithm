// **************************************************************************
// File       [global.h]
// Author     [CM Li]
// Synopsis   [define global variables]
// Modify     
// **************************************************************************

#ifndef _GLOBAL_H_
#define _GLOBAL_H_



#define VECTOR_SIZE 10  // define the vector size 


#endif
