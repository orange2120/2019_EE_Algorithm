/* 
filename: replacable_sorter 
Author: James Li
Description:  header file for replaceable sorter
Revision: V 2010.2
*/

void replaceable_sorter(int x[],int length);
